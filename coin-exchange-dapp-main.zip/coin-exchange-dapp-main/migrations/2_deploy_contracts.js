const Token = artifacts.require("Token");
const Exchange = artifacts.require("Exchange");

module.exports = async function(deployer) {
  const accounts = await web3.eth.getAccounts()

  // Deploy Token with 1,000,000 tokens (with 18 decimals)
  const totalSupply = '1000000000000000000000000' // 1,000,000 * 10^18
  await deployer.deploy(Token, totalSupply);

  // Deploy Exchange with deployer as fee account and 10% fee
  const feeAccount = accounts[0]
  const feePercent = 10
  await deployer.deploy(Exchange, feeAccount, feePercent)
};
