import React, { Component } from 'react';
import './App.css';
import Web3 from 'web3';
import Token from '../abis/Token.json';
import Exchange from '../abis/Exchange.json';

// ITMCoin Exchange - Main Application Component
// This single React class component handles all exchange functionality:
// - Connecting to MetaMask
// - Loading balances
// - Displaying order book
// - Making/cancelling/filling orders
// - Deposit/withdraw ETH and tokens

class App extends Component {
  // Initialize state with empty values
  state = {
    account: '',
    web3: null,
    token: null,
    exchange: null,
    ethBalance: '0',
    tokenBalance: '0',
    exchangeEthBalance: '0',
    exchangeTokenBalance: '0',
    orders: [],
    cancelledOrders: [],
    filledOrders: [],
    depositEthAmount: '',
    withdrawEthAmount: '',
    depositTokenAmount: '',
    withdrawTokenAmount: '',
    buyAmount: '',
    buyPrice: '',
    sellAmount: '',
    sellPrice: '',
    loading: true
  }

  // Called when component mounts - load blockchain data
  async componentDidMount() {
    await this.loadBlockchainData();
  }

  // Connect to MetaMask and load all contract data
  async loadBlockchainData() {
    try {
      // Check if MetaMask is installed
      if (!window.ethereum) {
        alert('Please install MetaMask to use this exchange!');
        return;
      }

      // Request account access
      await window.ethereum.request({ method: 'eth_requestAccounts' });

      // Create Web3 instance
      const web3 = new Web3(window.ethereum);
      this.setState({ web3 });

      // Get connected account
      const accounts = await web3.eth.getAccounts();
      this.setState({ account: accounts[0] });

      // Get network ID to find deployed contracts
      const networkId = await web3.eth.net.getId();

      // Load Token contract
      const tokenData = Token.networks[networkId];
      if (!tokenData) {
        alert('Token contract not deployed to this network!');
        return;
      }
      const token = new web3.eth.Contract(Token.abi, tokenData.address);
      this.setState({ token });

      // Load Exchange contract
      const exchangeData = Exchange.networks[networkId];
      if (!exchangeData) {
        alert('Exchange contract not deployed to this network!');
        return;
      }
      const exchange = new web3.eth.Contract(Exchange.abi, exchangeData.address);
      this.setState({ exchange });

      // Load balances and orders
      await this.loadBalances();
      await this.loadOrders();

      this.setState({ loading: false });

      // Listen for account changes in MetaMask
      window.ethereum.on('accountsChanged', (accounts) => {
        this.setState({ account: accounts[0] }, () => {
          this.loadBalances();
        });
      });
    } catch (error) {
      console.error('Error loading blockchain data:', error);
      this.setState({ loading: false });
    }
  }

  // Load user's ETH and token balances (wallet + exchange)
  loadBalances = async () => {
    const { web3, token, exchange, account } = this.state;
    if (!web3 || !token || !exchange || !account) return;

    // Wallet ETH balance
    const ethBalance = await web3.eth.getBalance(account);
    this.setState({ ethBalance: web3.utils.fromWei(ethBalance, 'ether') });

    // Wallet token balance
    const tokenBalance = await token.methods.balanceOf(account).call();
    this.setState({ tokenBalance: web3.utils.fromWei(tokenBalance, 'ether') });

    // Exchange ETH balance
    const ETHER_ADDRESS = '0x0000000000000000000000000000000000000000';
    const exchangeEthBalance = await exchange.methods.balanceOf(ETHER_ADDRESS, account).call();
    this.setState({ exchangeEthBalance: web3.utils.fromWei(exchangeEthBalance, 'ether') });

    // Exchange token balance
    const exchangeTokenBalance = await exchange.methods.balanceOf(token._address, account).call();
    this.setState({ exchangeTokenBalance: web3.utils.fromWei(exchangeTokenBalance, 'ether') });
  }

  // Load all orders from the exchange
  loadOrders = async () => {
    const { exchange } = this.state;
    if (!exchange) return;

    const orderCount = await exchange.methods.orderCount().call();
    const orders = [];
    const cancelledOrders = [];
    const filledOrders = [];

    for (let i = 1; i <= orderCount; i++) {
      const order = await exchange.methods.orders(i).call();
      const isCancelled = await exchange.methods.orderCancelled(i).call();
      const isFilled = await exchange.methods.orderFilled(i).call();

      if (isCancelled) {
        cancelledOrders.push(order);
      } else if (isFilled) {
        filledOrders.push(order);
      } else {
        orders.push(order);
      }
    }

    this.setState({ orders, cancelledOrders, filledOrders });
  }

  // Deposit ETH to exchange
  depositEth = async (e) => {
    e.preventDefault();
    const { web3, exchange, account, depositEthAmount } = this.state;
    const amount = web3.utils.toWei(depositEthAmount, 'ether');
    await exchange.methods.depositEther().send({ from: account, value: amount });
    this.setState({ depositEthAmount: '' });
    await this.loadBalances();
  }

  // Withdraw ETH from exchange
  withdrawEth = async (e) => {
    e.preventDefault();
    const { web3, exchange, account, withdrawEthAmount } = this.state;
    const amount = web3.utils.toWei(withdrawEthAmount, 'ether');
    await exchange.methods.withdrawEther(amount).send({ from: account });
    this.setState({ withdrawEthAmount: '' });
    await this.loadBalances();
  }

  // Deposit tokens to exchange
  depositToken = async (e) => {
    e.preventDefault();
    const { web3, token, exchange, account, depositTokenAmount } = this.state;
    const amount = web3.utils.toWei(depositTokenAmount, 'ether');
    // First approve, then deposit
    await token.methods.approve(exchange._address, amount).send({ from: account });
    await exchange.methods.depositToken(token._address, amount).send({ from: account });
    this.setState({ depositTokenAmount: '' });
    await this.loadBalances();
  }

  // Withdraw tokens from exchange
  withdrawToken = async (e) => {
    e.preventDefault();
    const { web3, token, exchange, account, withdrawTokenAmount } = this.state;
    const amount = web3.utils.toWei(withdrawTokenAmount, 'ether');
    await exchange.methods.withdrawToken(token._address, amount).send({ from: account });
    this.setState({ withdrawTokenAmount: '' });
    await this.loadBalances();
  }

  // Create a buy order (buy ITM with ETH)
  makeBuyOrder = async (e) => {
    e.preventDefault();
    const { web3, token, exchange, account, buyAmount, buyPrice } = this.state;
    const ETHER_ADDRESS = '0x0000000000000000000000000000000000000000';
    const tokenAmount = web3.utils.toWei(buyAmount, 'ether');
    const ethAmount = web3.utils.toWei((parseFloat(buyAmount) * parseFloat(buyPrice)).toString(), 'ether');
    await exchange.methods.makeOrder(token._address, tokenAmount, ETHER_ADDRESS, ethAmount).send({ from: account });
    this.setState({ buyAmount: '', buyPrice: '' });
    await this.loadOrders();
  }

  // Create a sell order (sell ITM for ETH)
  makeSellOrder = async (e) => {
    e.preventDefault();
    const { web3, token, exchange, account, sellAmount, sellPrice } = this.state;
    const ETHER_ADDRESS = '0x0000000000000000000000000000000000000000';
    const tokenAmount = web3.utils.toWei(sellAmount, 'ether');
    const ethAmount = web3.utils.toWei((parseFloat(sellAmount) * parseFloat(sellPrice)).toString(), 'ether');
    await exchange.methods.makeOrder(ETHER_ADDRESS, ethAmount, token._address, tokenAmount).send({ from: account });
    this.setState({ sellAmount: '', sellPrice: '' });
    await this.loadOrders();
  }

  // Fill an existing order
  fillOrder = async (orderId) => {
    const { exchange, account } = this.state;
    await exchange.methods.fillOrder(orderId).send({ from: account });
    await this.loadOrders();
    await this.loadBalances();
  }

  // Cancel your own order
  cancelOrder = async (orderId) => {
    const { exchange, account } = this.state;
    await exchange.methods.cancelOrder(orderId).send({ from: account });
    await this.loadOrders();
  }

  // Format price from order data
  formatPrice = (order) => {
    const { web3, token } = this.state;
    if (!web3) return '0';
    const ETHER_ADDRESS = '0x0000000000000000000000000000000000000000';
    const tokenGet = order.tokenGet.toLowerCase();
    const tokenAddress = token._address.toLowerCase();

    if (tokenGet === tokenAddress) {
      // Buy order: wants tokens, gives ETH
      const tokenAmount = parseFloat(web3.utils.fromWei(order.amountGet, 'ether'));
      const ethAmount = parseFloat(web3.utils.fromWei(order.amountGive, 'ether'));
      return (ethAmount / tokenAmount).toFixed(6);
    } else {
      // Sell order: wants ETH, gives tokens
      const ethAmount = parseFloat(web3.utils.fromWei(order.amountGet, 'ether'));
      const tokenAmount = parseFloat(web3.utils.fromWei(order.amountGive, 'ether'));
      return (ethAmount / tokenAmount).toFixed(6);
    }
  }

  // Check if order is a buy order
  isBuyOrder = (order) => {
    const { token } = this.state;
    if (!token) return false;
    return order.tokenGet.toLowerCase() === token._address.toLowerCase();
  }

  render() {
    const { account, loading, ethBalance, tokenBalance, exchangeEthBalance, exchangeTokenBalance,
      orders, filledOrders, depositEthAmount, withdrawEthAmount, depositTokenAmount, withdrawTokenAmount,
      buyAmount, buyPrice, sellAmount, sellPrice, web3 } = this.state;

    // Truncate wallet address for display
    const displayAccount = account ? `${account.slice(0, 6)}...${account.slice(-4)}` : 'Not connected';

    // Separate buy and sell orders
    const buyOrders = orders.filter(o => this.isBuyOrder(o));
    const sellOrders = orders.filter(o => !this.isBuyOrder(o));

    return (
      <div>
        {/* HEADER */}
        <nav className="navbar navbar-dark">
          <span className="navbar-brand">ITMCoin Exchange</span>
          <span className="wallet-address">{displayAccount}</span>
        </nav>

        {loading ? (
          <div className="loading">Loading... Please connect MetaMask</div>
        ) : (
          <div className="content">
            {/* BALANCE PANEL */}
            <div className="vertical-split">
              <div className="card">
                <div className="card-header">Balances</div>
                <div className="card-body">
                  <table className="table table-sm">
                    <thead><tr><th>Token</th><th>Wallet</th><th>Exchange</th></tr></thead>
                    <tbody>
                      <tr><td>ETH</td><td>{parseFloat(ethBalance).toFixed(4)}</td><td>{parseFloat(exchangeEthBalance).toFixed(4)}</td></tr>
                      <tr><td>ITM</td><td>{parseFloat(tokenBalance).toFixed(4)}</td><td>{parseFloat(exchangeTokenBalance).toFixed(4)}</td></tr>
                    </tbody>
                  </table>
                </div>
              </div>

              {/* DEPOSIT/WITHDRAW FORMS */}
              <div className="card">
                <div className="card-header">Deposit / Withdraw</div>
                <div className="card-body">
                  <form onSubmit={this.depositEth} className="form-inline mb-2">
                    <input type="text" className="form-control form-control-sm mr-1" placeholder="ETH Amount" value={depositEthAmount} onChange={(e) => this.setState({ depositEthAmount: e.target.value })} />
                    <button type="submit" className="btn btn-sm btn-primary">Deposit ETH</button>
                  </form>
                  <form onSubmit={this.withdrawEth} className="form-inline mb-2">
                    <input type="text" className="form-control form-control-sm mr-1" placeholder="ETH Amount" value={withdrawEthAmount} onChange={(e) => this.setState({ withdrawEthAmount: e.target.value })} />
                    <button type="submit" className="btn btn-sm btn-danger">Withdraw ETH</button>
                  </form>
                  <form onSubmit={this.depositToken} className="form-inline mb-2">
                    <input type="text" className="form-control form-control-sm mr-1" placeholder="ITM Amount" value={depositTokenAmount} onChange={(e) => this.setState({ depositTokenAmount: e.target.value })} />
                    <button type="submit" className="btn btn-sm btn-primary">Deposit ITM</button>
                  </form>
                  <form onSubmit={this.withdrawToken} className="form-inline">
                    <input type="text" className="form-control form-control-sm mr-1" placeholder="ITM Amount" value={withdrawTokenAmount} onChange={(e) => this.setState({ withdrawTokenAmount: e.target.value })} />
                    <button type="submit" className="btn btn-sm btn-danger">Withdraw ITM</button>
                  </form>
                </div>
              </div>
            </div>

            {/* ORDER BOOK */}
            <div className="vertical">
              <div className="card">
                <div className="card-header">Order Book</div>
                <div className="card-body">
                  <h6 className="text-danger">Sell Orders</h6>
                  <table className="table table-sm">
                    <thead><tr><th>ITM</th><th>Price (ETH)</th><th>Action</th></tr></thead>
                    <tbody>
                      {sellOrders.map(order => (
                        <tr key={order.id} className="order-book-order text-danger">
                          <td>{web3 ? parseFloat(web3.utils.fromWei(order.amountGive, 'ether')).toFixed(2) : '0'}</td>
                          <td>{this.formatPrice(order)}</td>
                          <td><button className="btn btn-xs btn-success" onClick={() => this.fillOrder(order.id)}>Buy</button></td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  <h6 className="text-success mt-3">Buy Orders</h6>
                  <table className="table table-sm">
                    <thead><tr><th>ITM</th><th>Price (ETH)</th><th>Action</th></tr></thead>
                    <tbody>
                      {buyOrders.map(order => (
                        <tr key={order.id} className="order-book-order text-success">
                          <td>{web3 ? parseFloat(web3.utils.fromWei(order.amountGet, 'ether')).toFixed(2) : '0'}</td>
                          <td>{this.formatPrice(order)}</td>
                          <td><button className="btn btn-xs btn-danger" onClick={() => this.fillOrder(order.id)}>Sell</button></td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            {/* NEW ORDER + MY ORDERS */}
            <div className="vertical-split">
              <div className="card">
                <div className="card-header">New Order</div>
                <div className="card-body">
                  <h6 className="text-success">Buy ITM</h6>
                  <form onSubmit={this.makeBuyOrder} className="mb-3">
                    <input type="text" className="form-control form-control-sm mb-1" placeholder="ITM Amount" value={buyAmount} onChange={(e) => this.setState({ buyAmount: e.target.value })} />
                    <input type="text" className="form-control form-control-sm mb-1" placeholder="Price (ETH per ITM)" value={buyPrice} onChange={(e) => this.setState({ buyPrice: e.target.value })} />
                    <button type="submit" className="btn btn-sm btn-success btn-block">Buy</button>
                  </form>
                  <h6 className="text-danger">Sell ITM</h6>
                  <form onSubmit={this.makeSellOrder}>
                    <input type="text" className="form-control form-control-sm mb-1" placeholder="ITM Amount" value={sellAmount} onChange={(e) => this.setState({ sellAmount: e.target.value })} />
                    <input type="text" className="form-control form-control-sm mb-1" placeholder="Price (ETH per ITM)" value={sellPrice} onChange={(e) => this.setState({ sellPrice: e.target.value })} />
                    <button type="submit" className="btn btn-sm btn-danger btn-block">Sell</button>
                  </form>
                </div>
              </div>

              <div className="card">
                <div className="card-header">My Orders</div>
                <div className="card-body">
                  <table className="table table-sm">
                    <thead><tr><th>Type</th><th>ITM</th><th>Price</th><th></th></tr></thead>
                    <tbody>
                      {orders.filter(o => o.user.toLowerCase() === account.toLowerCase()).map(order => (
                        <tr key={order.id}>
                          <td className={this.isBuyOrder(order) ? 'text-success' : 'text-danger'}>{this.isBuyOrder(order) ? 'BUY' : 'SELL'}</td>
                          <td>{web3 ? parseFloat(web3.utils.fromWei(this.isBuyOrder(order) ? order.amountGet : order.amountGive, 'ether')).toFixed(2) : '0'}</td>
                          <td>{this.formatPrice(order)}</td>
                          <td><button className="btn btn-xs btn-secondary" onClick={() => this.cancelOrder(order.id)}>X</button></td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            {/* TRADE HISTORY */}
            <div className="vertical">
              <div className="card">
                <div className="card-header">Trade History</div>
                <div className="card-body">
                  <table className="table table-sm">
                    <thead><tr><th>ITM</th><th>Price</th><th>Time</th></tr></thead>
                    <tbody>
                      {filledOrders.slice(-10).reverse().map(order => (
                        <tr key={order.id}>
                          <td>{web3 ? parseFloat(web3.utils.fromWei(this.isBuyOrder(order) ? order.amountGet : order.amountGive, 'ether')).toFixed(2) : '0'}</td>
                          <td>{this.formatPrice(order)}</td>
                          <td>{new Date(parseInt(order.timestamp) * 1000).toLocaleTimeString()}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }
}

export default App;
